#Data Gaps TNHA


filepath = "~/Desktop/Arctic/X-Y_Plots/data/raw/" #Set to prefix of your file location

summer = c("Season_GRNDTMP_6_19_22_9_20_22_2022_09_21_16_19_26_UTC_1.csv",
           "Season_SOLARAD_6_19_22_9_20_22_2022_09_21_16_27_20_UTC_1.csv",
           "Season_AIRTMP_6_19_22_9_20_22_2022_09_21_16_21_48_UTC_1.csv",
           "Season_VWC_6_19_22_9_20_22_2022_09_21_16_11_28_UTC_1.csv")

filenames = summer
grnd_file = filenames[1]
solar_file = filenames[2]
air_file = filenames[3]
mst_file = filenames[4]

grndtmp=read.csv(paste(filepath,grnd_file,sep = ""))

names(grndtmp) <- sub("....C..RX3000_BRW1", "", names(grndtmp))
names(grndtmp) <- sub("....C..RX3000_BRW4", "", names(grndtmp))
names(grndtmp) <- sub("....C..RX3000_BRW5", "", names(grndtmp))
names(grndtmp) <- sub("....C..RX3000_BRW6", "", names(grndtmp))
names(grndtmp) <- sub(".RXW.GP6.", "", names(grndtmp))
names(grndtmp) <- sub("Temperature.", "", names(grndtmp))
grndtmp$Date <-as.POSIXct(grndtmp$Date,format="%m/%d/%y %H:%M",tz="UTC")

grndtmp = grndtmp[,-14] #Air temp sensor

#Ground Temperature
grndtmp = gather(grndtmp, variable, response, 3:ncol(grndtmp)) %>%
  filter(!is.na(response)) %>%
  mutate(variable = fct_inorder(variable))

grndtmp= cSplit(grndtmp, 'variable', sep=".", direction = "wide") # texttocols, 
colnames(grndtmp)[3:6] <- c("value", "station", "sensor","depth")
grndtmp$value <- as.numeric(as.character(grndtmp$value)) 
grndtmp$sensor <- as.factor(as.character(grndtmp$sensor))
grndtmp$station <- as.factor(grndtmp$station)

grndtmp$station <- revalue(grndtmp$station, c("21198259" = "TNHA", "21401800" = "BUCEI", "21401801" = "SSMH", "21401803" = "BEO"))
grndtmp$sensor <- revalue(grndtmp$sensor, c("21398585" = "BUCEI-BASE", "21398590" = "BUCEI-SA", "21398583" = "BUCEI-SB", "21393042" = "BUCEI-SC", "21398584" = "BUCEI-SD", "21398579" = "BUCEI-SE", "21398578" = "BUCEI-SF.01", "21398598" = "BUCEI-SF.02", "21398588" ="SSMH-BASE","21393049" = "SSMH-SD", "21398599" = "SSMH-SA", "21393044" = "SSMH-SB", "21393049" = "SSMH-SD" , "21206939" = "TNHA-BASE", "21398593" = "TNHA-SA", "21398576"="TNHA-SB","21398601" = "TNHA-SD", "21393047" = "TNHA-SC", "21393048" = "BEO-B06", "21398591" = "BEO-B05"))



#Look for TNHA-SB
sb = grndtmp[grndtmp$sensor == "TNHA-SB"]

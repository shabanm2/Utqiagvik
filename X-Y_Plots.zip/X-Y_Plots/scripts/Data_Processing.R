# ---Author Notes---
# 
# This R Script is used to process raw data and track the progression/analysis
# of the data as referenced in the project.
# 
# Data outputs are found in the "processed" directory under "data"
# This file will only need to be run if the processed data is missing or
# the methodology of processing the data is altered.
# 
# Elizabeth Van Metre
# 3/8/2023

#FILEPATHS AND DATA SETUP

filepath = "~/Desktop/Arctic/X-Y_Plots/data/raw/" #Set to prefix of your file location
export_to = "~/Desktop/Arctic/X-Y_Plots/data/processed/" #Directory to export clean data sets


#PACKAGES
library(plyr)
library(dplyr)
library(lubridate)
library(tidyr)
library(gridExtra)
library(forcats)
library(splitstackshape)
library(naniar)
library(RColorBrewer)
library(caret)



#RAW DATA LOADING

    #Ground Temperature
    grndtmp=read.csv(paste(filepath,"Season_GRNDTMP_6_19_22_9_20_22_2022_09_21_16_19_26_UTC_1.csv",sep = ""))
    
    names(grndtmp) <- sub("....C..RX3000_BRW1", "", names(grndtmp))
    names(grndtmp) <- sub("....C..RX3000_BRW4", "", names(grndtmp))
    names(grndtmp) <- sub("....C..RX3000_BRW5", "", names(grndtmp))
    names(grndtmp) <- sub("....C..RX3000_BRW6", "", names(grndtmp))
    names(grndtmp) <- sub(".RXW.GP6.", "", names(grndtmp))
    names(grndtmp) <- sub("Temperature.", "", names(grndtmp))
    grndtmp$Date <-as.POSIXct(grndtmp$Date,format="%m/%d/%y %H:%M",tz="UTC")
    
    grndtmp = grndtmp[,-14] #Air temp sensor
    
    write.csv(grndtmp, file=paste(export_to, "grndtmp.csv", sep=""))
    
    
    #Solar Radiation
    solarrad = read.csv(paste(filepath,"Season_SOLARAD_6_19_22_9_20_22_2022_09_21_16_27_20_UTC_1.csv",sep = ""))
    
    names(solarrad) <- sub("olar.Radiation..RXW.LIB", "" ,names(solarrad))
    names(solarrad) <- sub("olar.Radiation..S.LIB", "" ,names(solarrad))
    names(solarrad) <- sub("S.", "" ,names(solarrad))
    names(solarrad) <- sub("...W.m.2..RX3000_BRW1", "" ,names(solarrad))
    names(solarrad) <- sub("...W.m.2..RX3000_BRW4", "" ,names(solarrad))
    names(solarrad) <- sub("...W.m.2..RX3000_BRW5", "" ,names(solarrad))
    names(solarrad) <- sub("...W.m.2..RX3000_BRW6", "" ,names(solarrad))
    solarrad$Date <- as.POSIXct(solarrad$Date,format="%m/%d/%y %H:%M",tz="UTC")
    
    write.csv(solarrad, file=paste(export_to, "solar.csv", sep=""))


    #Air Temperature
    airtemp =read.csv(paste(filepath,"Season_AIRTMP_6_19_22_9_20_22_2022_09_21_16_21_48_UTC_1.csv",sep = ""))
    
    names(airtemp) <- sub("Temperature..RXW.THC.", "" ,names(airtemp))
    names(airtemp) <- sub("Temperature..S.THC.", "" ,names(airtemp))
    names(airtemp) <- sub("S.", "" ,names(airtemp))
    names(airtemp) <- sub("....C..RX3000_BRW1", "" ,names(airtemp))
    names(airtemp) <- sub("....C..RX3000_BRW4", "" ,names(airtemp))
    names(airtemp) <- sub("....C..RX3000_BRW5", "" ,names(airtemp))
    names(airtemp) <- sub("....C..RX3000_BRW6", "" ,names(airtemp))
    airtemp$Date <- as.POSIXct(airtemp$Date,format="%m/%d/%y %H:%M",tz="UTC")
    write.csv(airtemp, file=paste(export_to, "airtemp.csv", sep=""))


    #Ground Moisture
    mst=read.csv(paste(filepath,"Season_VWC_6_19_22_9_20_22_2022_09_21_16_11_28_UTC_1.csv",sep = ""))
    
    names(mst) <- sub("...m.3.m.3..RX3000_BRW1", "", names(mst))
    names(mst) <- sub("...m.3.m.3..RX3000_BRW4", "", names(mst))
    names(mst) <- sub("...m.3.m.3..RX3000_BRW5", "", names(mst))
    names(mst) <- sub("...m.3.m.3..RX3000_BRW6", "", names(mst))
    names(mst) <- sub("..RXW.GP6.", "", names(mst))
    names(mst) <- sub("Water.Content", "", names(mst))
    mst$Date <-as.POSIXct(mst$Date,format="%m/%d/%y %H:%M",tz="UTC")
    
    write.csv(mst, file=paste(export_to, "mst.csv", sep=""))


#CREATE LONG DATAFRAMES

    #Solar Radiation
    solarrad = gather(solarrad, variable, response, 3:ncol(solarrad)) %>%
      filter(!is.na(response)) %>%
      mutate(variable = fct_inorder(variable))
    
    solarrad= cSplit(solarrad, 'variable', sep=".", direction = "wide") # texttocols, 
    solarrad$variable_3 <- NULL
    colnames(solarrad)[3:5] <- c("value", "station", "sensor")
    solarrad$value <- as.numeric(as.character(solarrad$value)) 
    solarrad$sensor <- as.factor(as.character(solarrad$sensor))
    solarrad$station <- as.factor(solarrad$station)
    
    solarrad$station <- revalue(solarrad$station, c("21198259" = "TNHA", "21401800" = "BUCEI", "21401801" = "SSMH", "21401803" = "BEO"))
    
    solarrad$sensor <- revalue(solarrad$sensor, c("21390411" = "BUCEI-BASE", "21398618" = "BUCEI-SA", "21398624" = "BUCEI-SB", "21362313" = "BUCEI-SC", "21362316" = "BUCEI-SD", "21362320" = "BUCEI-SE", "21398578" = "BUCEI-SF.01", "21398598" = "BUCEI-SF.02", 
                                                  "21390413" ="SSMH-BASE", "21398622" = "SSMH-SA", "21362319" = "SSMH-SB", "21166008" = "SSMH-SC", "21393049" = "SSMH-SD" ,
                                                  "21176526" = "TNHA-BASE", "21398620" = "TNHA-SA", "21398616"="TNHA-SB","21362315" = "TNHA-SD", "21362317" = "TNHA-SC", 
                                                  "21390415" = "BEO-Base"))
    write.csv(solarrad, file=paste(export_to, "solar_long.csv", sep=""))
    
    
    #Ground Temperature
    grndtmp = gather(grndtmp, variable, response, 3:ncol(grndtmp)) %>%
      filter(!is.na(response)) %>%
      mutate(variable = fct_inorder(variable))
    
    grndtmp= cSplit(grndtmp, 'variable', sep=".", direction = "wide") # texttocols, 
    colnames(grndtmp)[3:6] <- c("value", "station", "sensor","depth")
    grndtmp$value <- as.numeric(as.character(grndtmp$value)) 
    grndtmp$sensor <- as.factor(as.character(grndtmp$sensor))
    grndtmp$station <- as.factor(grndtmp$station)
    
    grndtmp$station <- revalue(grndtmp$station, c("21198259" = "TNHA", "21401800" = "BUCEI", "21401801" = "SSMH", "21401803" = "BEO"))
    grndtmp$sensor <- revalue(grndtmp$sensor, c("21398585" = "BUCEI-BASE", "21398590" = "BUCEI-SA", "21398583" = "BUCEI-SB", "21393042" = "BUCEI-SC", "21398584" = "BUCEI-SD", "21398579" = "BUCEI-SE", "21398578" = "BUCEI-SF.01", "21398598" = "BUCEI-SF.02", "21398588" ="SSMH-BASE","21393049" = "SSMH-SD", "21398599" = "SSMH-SA", "21393044" = "SSMH-SB", "21393049" = "SSMH-SD" , "21206939" = "TNHA-BASE", "21398593" = "TNHA-SA", "21398576"="TNHA-SB","21398601" = "TNHA-SD", "21393047" = "TNHA-SC", "21393048" = "BEO-B06", "21398591" = "BEO-B05"))

    write.csv(grndtmp, file=paste(export_to, "grndtmp_long.csv", sep=""))
    
    
    #Ground Moisture
    grndmst = gather(mst, variable, response, 3:ncol(mst)) %>%
      filter(!is.na(response)) %>%
      mutate(variable = fct_inorder(variable))
    
    grndmst= cSplit(grndmst, 'variable', sep=".", direction = "wide") # texttocols, 
    colnames(grndmst)[3:6] <- c("value", "station", "sensor","depth")
    grndmst$value <- as.numeric(as.character(grndmst$value)) 
    grndmst$sensor <- as.factor(as.character(grndmst$sensor))
    grndmst$station <- as.factor(grndmst$station)
    
    grndmst$station <- revalue(grndmst$station, c("21198259" = "TNHA", "21401800" = "BUCEI", "21401801" = "SSMH", "21401803" = "BEO"))
    grndmst$sensor <- revalue(grndmst$sensor, c("21398585" = "BUCEI-BASE", "21398590" = "BUCEI-SA", "21398583" = "BUCEI-SB", "21393042" = "BUCEI-SC", "21398584" = "BUCEI-SD", "21398579" = "BUCEI-SE", "21398578" = "BUCEI-SF.01", "21398598" = "BUCEI-SF.02", "21398588" ="SSMH-BASE","21393049" = "SSMH-SD", "21398599" = "SSMH-SA", "21393044" = "SSMH-SB", "21393049" = "SSMH-SD" , "21206939" = "TNHA-BASE", "21398593" = "TNHA-SA", "21398576"="TNHA-SB","21398601" = "TNHA-SD", "21393047" = "TNHA-SC", "21393048" = "BEO-B06", "21398591" = "BEO-B05"))
    
    write.csv(grndmst, file=paste(export_to, "mst_long.csv", sep=""))
    
    #Air Temperature
    airtemp = gather(mst, variable, response, 3:ncol(mst)) %>%
      filter(!is.na(response)) %>%
      mutate(variable = fct_inorder(variable))
    
    airtemp= cSplit(airtemp, 'variable', sep=".", direction = "wide") # texttocols, 
    colnames(airtemp)[3:6] <- c("value", "station", "sensor","depth")
    airtemp$value <- as.numeric(as.character(airtemp$value)) 
    airtemp$sensor <- as.factor(as.character(airtemp$sensor))
    airtemp$station <- as.factor(airtemp$station)
    
    airtemp$station <- revalue(airtemp$station, c("21198259" = "TNHA", "21401800" = "BUCEI", "21401801" = "SSMH", "21401803" = "BEO"))
    airtemp$sensor <- revalue(airtemp$sensor, c("21398585" = "BUCEI-BASE", "21398590" = "BUCEI-SA", "21398583" = "BUCEI-SB", "21393042" = "BUCEI-SC", "21398584" = "BUCEI-SD", "21398579" = "BUCEI-SE", "21398578" = "BUCEI-SF.01", "21398598" = "BUCEI-SF.02", "21398588" ="SSMH-BASE","21393049" = "SSMH-SD", "21398599" = "SSMH-SA", "21393044" = "SSMH-SB", "21393049" = "SSMH-SD" , "21206939" = "TNHA-BASE", "21398593" = "TNHA-SA", "21398576"="TNHA-SB","21398601" = "TNHA-SD", "21393047" = "TNHA-SC", "21393048" = "BEO-B06", "21398591" = "BEO-B05"))
    
    write.csv(airtemp, file=paste(export_to, "airtemp_long", sep=""))
    
    
    
#GET AVERAGES AND AMPLITUDES
    
    grndtmp$Date = floor_date(grndtmp$Date, unit = "days", week_start = getOption("lubridate.week.start",7))
    grndtmp_avg = grndtmp %>% group_by(Date, station, sensor, depth) %>% summarise(average = mean(value), max = max(value), min = min(value)) %>% mutate(amplitude = max-min)
    
    solarrad$Date = floor_date(solarrad$Date, unit = "days", week_start = getOption("lubridate.week.start",7))
    solar_avg = solarrad %>% group_by(Date, station, sensor) %>% summarise(average = mean(value), max = max(value), min = min(value)) %>% mutate(amplitude = max-min)
    
    grndmst$Date = floor_date(grndmst$Date, unit = "days", week_start = getOption("lubridate.week.start",7))
    mst_avg = grndmst %>% group_by(Date, station, sensor, depth) %>% summarise(average = mean(value), max = max(value), min = min(value)) %>% mutate(amplitude = max-min)
    
    airtemp$Date = floor_date(airtemp$Date, unit = "days", week_start = getOption("lubridate.week.start",7))
    air_avg = airtemp %>% group_by(Date, station, sensor, depth) %>% summarise(average = mean(value), max = max(value), min = min(value)) %>% mutate(amplitude = max-min)
    
    
#JOIN INTO LARGE DF
    
    solar_avg = solar_avg[,1:4]
    colnames(solar_avg)[4] <- "solar_avg"
    
    grndtmp_avg = grndtmp_avg[,c(1,2,3,4,5,8)]
    colnames(grndtmp_avg)[4:6] <- c("grn_depth","grndtmp_avg", "grndtmp_amp")
    
    air_avg = air_avg[,1:5]
    colnames(air_avg)[4:5] <- c("air_depth", "air_avg")
    
    mst_avg = mst_avg[,1:5]
    colnames(mst_avg)[4:5] <- c("mst_depth","mst_avg")
    
    averages = grndtmp_avg %>% full_join(solar_avg, by=c("Date","sensor","station")) %>% 
      full_join(air_avg, by=c("Date","sensor","station")) %>% 
      full_join(mst_avg, by=c("Date","sensor","station"))
    averages = na_if(averages, -888.8800) #Outliers
    
    #NOTE: because of depth differentials, this makes this dataframe HORRIFYING. However, it has most data we need for the XY Graphs.
    
    write.csv(averages, file=paste(export_to, "xy-df.csv", sep=""))
    